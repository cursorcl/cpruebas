/**
 * Provides data normalization techniques
 */
package org.neuroph.core.data.norm;
