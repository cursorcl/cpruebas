/**
 * Provides common neuron transfer functions
 */

package org.neuroph.core.transfer;

