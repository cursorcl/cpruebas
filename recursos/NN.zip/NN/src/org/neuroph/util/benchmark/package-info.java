/**
 * Provides microbenchmaarking framework for measuring and comparing Neuroph performance.
 */
package org.neuroph.util.benchmark;
