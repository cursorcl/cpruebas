/**
 * Provides stop functions for learning rules
 */
package org.neuroph.core.learning.stop;
