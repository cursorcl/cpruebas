package org.neuroph.nnet;

import org.neuroph.core.NeuralNetwork;
import org.neuroph.nnet.learning.BackPropagation;

/**
 *
 * @author zoran
 */
public class AutoencoderNetwork extends NeuralNetwork<BackPropagation>  {

    public AutoencoderNetwork(int ... neuronsInLayers) {
        // neurons in first layer == neurns in last layer 
       
        
        // everything else like MLP
    }
    
}
