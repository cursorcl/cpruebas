/**
 * Provides various specific layer types
 */

package org.neuroph.nnet.comp.layer;
